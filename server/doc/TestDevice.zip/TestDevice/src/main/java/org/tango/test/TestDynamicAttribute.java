package org.tango.test;

import org.tango.DeviceState;
import org.tango.server.StateMachineBehavior;
import org.tango.server.attribute.AttributeConfiguration;
import org.tango.server.attribute.AttributePropertiesImpl;
import org.tango.server.attribute.AttributeValue;
import org.tango.server.attribute.IAttributeBehavior;
import org.tango.server.attribute.ISetValueUpdater;

import fr.esrf.Tango.AttrWriteType;
import fr.esrf.Tango.DevFailed;

/**
 * A sample attribute
 * 
 * @author ABEILLE
 * 
 */
public class TestDynamicAttribute implements IAttributeBehavior, ISetValueUpdater {

    private double readValue = 0;
    private double writeValue = 100;

    /**
     * Configure the attribute
     */
    @Override
    public AttributeConfiguration getConfiguration() throws DevFailed {
	final AttributeConfiguration config = new AttributeConfiguration();
	config.setName("testDynAttr");
	// attribute testDynAttr is a DevDouble
	config.setType(double.class);
	// attribute testDynAttr is READ_WRITE
	config.setWritable(AttrWriteType.READ_WRITE);
	// configure default attribute properties
	final AttributePropertiesImpl properties = new AttributePropertiesImpl();
	properties.setLabel("testDynAttr label");
	config.setAttributeProperties(properties);
	return config;
    }

    /**
     * Read the attribute
     */
    @Override
    public AttributeValue getValue() throws DevFailed {
	readValue = readValue + writeValue;
	return new AttributeValue(readValue);
    }

    /**
     * Write the attribute
     */
    @Override
    public void setValue(final AttributeValue value) throws DevFailed {
	writeValue = (Double) value.getValue();
    }

    /**
     * Configure state machine
     */
    @Override
    public StateMachineBehavior getStateMachine() throws DevFailed {
	StateMachineBehavior stateMachine = new StateMachineBehavior();
	// denied states when writing this attribute
	stateMachine.setDeniedStates(DeviceState.FAULT, DeviceState.OFF);
	// the state after writing this attribute
	stateMachine.setEndState(DeviceState.FAULT);
	return stateMachine;
    }

    /**
     * Return last written value
     */
    @Override
    public AttributeValue getSetValue() throws DevFailed {
	return new AttributeValue(writeValue);
    }

}
