package org.tango.test;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.tango.DeviceState;
import org.tango.server.ServerManager;
import org.tango.server.annotation.Attribute;
import org.tango.server.annotation.ClassProperty;
import org.tango.server.annotation.Command;
import org.tango.server.annotation.Delete;
import org.tango.server.annotation.Device;
import org.tango.server.annotation.DeviceManagement;
import org.tango.server.annotation.DeviceProperties;
import org.tango.server.annotation.DeviceProperty;
import org.tango.server.annotation.DynamicManagement;
import org.tango.server.annotation.Init;
import org.tango.server.annotation.State;
import org.tango.server.annotation.StateMachine;
import org.tango.server.device.DeviceManager;
import org.tango.server.dynamic.DynamicManager;
import org.tango.server.testserver.JTangoTest;

import fr.esrf.Tango.DevFailed;

@Device
public class TestDevice {

    private final Logger logger = LoggerFactory.getLogger(TestDevice.class);

    /**
     * A device property
     */
    @DeviceProperty(defaultValue = "", description = "an example device property")
    private String myProp;

    @ClassProperty(defaultValue = "0", description = "an example class property")
    private int myClassProp;

    @DeviceProperties
    private Map<String, String[]> deviceProperties;

    /**
     * Attribute myAttribute READ WRITE, type DevDouble.
     */
    @Attribute
    @StateMachine(deniedStates = DeviceState.FAULT, endState = DeviceState.DISABLE)
    public double myAttribute;

    /**
     * Manage dynamic attributes and commands
     */
    @DynamicManagement
    public DynamicManager dynamicManager;

    public void setDynamicManager(DynamicManager dynamicManager) {
	this.dynamicManager = dynamicManager;
    }

    /**
     * Manage state of the device
     */
    @State
    private DeviceState state = DeviceState.OFF;

    @DeviceManagement
    private DeviceManager deviceManager;

    /**
     * Starts the server.
     */
    public static void main(final String[] args) {
	ServerManager.getInstance().start(args, TestDevice.class);
    }

    public static final String NO_DB_DEVICE_NAME = "1/1/1";
    public static final String NO_DB_GIOP_PORT = "12354";
    public static final String NO_DB_INSTANCE_NAME = "1";

    /**
     * Starts the server in nodb mode.
     * 
     * @throws DevFailed
     */
    public static void startNoDb() {
	System.setProperty("OAPort", NO_DB_GIOP_PORT);
	ServerManager.getInstance().start(new String[] { NO_DB_INSTANCE_NAME, "-nodb", "-dlist", NO_DB_DEVICE_NAME },
		TestDevice.class);
    }

    /**
     * Starts the server in nodb mode with a file for device and class
     * properties
     * 
     * @throws DevFailed
     */
    public static void startNoDbFile() throws DevFailed {
	System.setProperty("OAPort", NO_DB_GIOP_PORT);
	ServerManager.getInstance().start(
		new String[] { NO_DB_INSTANCE_NAME, "-nodb", "-dlist", NO_DB_DEVICE_NAME,
			"-file=" + JTangoTest.class.getResource("/noDbproperties.txt").getPath() }, TestDevice.class);
    }

    /**
     * init device
     * 
     * @throws DevFailed
     */
    @Init
    @StateMachine(endState = DeviceState.ON)
    public void init() throws DevFailed {
	logger.debug("myProp value = {}", myProp);
	logger.debug("myClassProp value = {}", myClassProp);
	logger.debug("deviceProperties value = {}", deviceProperties);
	// create a new dynamic attribute
	dynamicManager.addAttribute(new TestDynamicAttribute());
	// create a new dynamic command
	dynamicManager.addCommand(new TestDynamicCommand());
	logger.debug("init done for device {} ", deviceManager.getName());
    }

    /**
     * delete device
     * 
     * @throws DevFailed
     */
    @Delete
    public void delete() throws DevFailed {
	logger.debug("delete");
	// remove all dynamic commands and attributes
	dynamicManager.clearAll();
    }

    /**
     * Execute command start.
     */
    @Command
    @StateMachine(endState = DeviceState.RUNNING, deniedStates = DeviceState.FAULT)
    public void start() {
	logger.debug("start");
    }

    /**
     * Read attribute myAttribute.
     * 
     * @return
     */
    public double getMyAttribute() {
	logger.debug("getMyAttribute {}", myAttribute);
	return myAttribute;
    }

    /**
     * Write attribute myAttribute
     * 
     * @param myAttribute
     */
    public void setMyAttribute(final double myAttribute) {
	logger.debug("setMyAttribute {}", myAttribute);
	this.myAttribute = myAttribute;
    }

    public void setMyProp(final String myProp) {
	this.myProp = myProp;
    }

    public void setMyClassProp(final int myClassProp) {
	this.myClassProp = myClassProp;
    }

    public DeviceState getState() {
	return state;
    }

    public void setState(final DeviceState state) {
	this.state = state;
    }

    public void setDeviceProperties(Map<String, String[]> deviceProperties) {
	this.deviceProperties = deviceProperties;
    }

    public void setDeviceManager(DeviceManager deviceManager) {
	this.deviceManager = deviceManager;
    }
}
